<?php 
include ("./inc/header.inc.php"); 
include ("./inc/nav.inc.php"); 
/* * * * * * * * * * * * * * * * * * * * main * * * * * * * * * * * * * * * * * * * */
?>

<img class="headerPic" src="img/event/event_header.jpg" alt="surfer">

<section class="gallery">
  <h4 class="paint-white">Events</h4>
  <br>
  <h2 class="paint-white">Something about your Event Loerum ipsum dolor sit.</h2>
  <br>
  <p class="paint-white">Try to finde one sentence or two to describe the concept of your page. Sports and camps describe a mood to make people feel whatever bla bla.</p>
</section>
