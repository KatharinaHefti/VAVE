<?php 
include ("./inc/header.inc.php"); 
include ("./inc/nav.inc.php"); 
/* * * * * * * * * * * * * * * * * * * * main * * * * * * * * * * * * * * * * * * * */
?>

<img class="headerPic" src="img/training/training_header.jpg" alt="valeria verzar">

<section class="gallery">
  <h4 class="paint-white">Training</h4>
  <br>
  <h2 class="paint-white">Something about your Training Loerum ipsum dolor sit.</h2>
  <br>
</section>
