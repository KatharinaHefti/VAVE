<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>VAVE</title>
  <!-- style -->
  <link rel="stylesheet" href="./style/style.css">  
  <!-- svg sprite -->
  <?php include('./img/sprites.svg'); ?>
</head>
<body>
